<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest`.
 */

$PHPMAILER_LANG['empty_message'] = 'This file should not be loaded as the path is passed incorrectly';
